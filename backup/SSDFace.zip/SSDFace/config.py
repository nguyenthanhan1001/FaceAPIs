FACE_MODEL = '/home/mmhci_hcmus/SSDFace/model/model.ckpt-70000'
PERSON_MODEL= '/home/mmhci_hcmus/SSDFace/model/VGG_VOC0712_SSD_300x300_ft_iter_120000.ckpt'