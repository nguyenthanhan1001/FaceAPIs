VGG16_DIR = '../vgg16'
SSD_API = 'http://128.199.90.168:8000/detect'
OPENCV_API = 'http://localhost:8000/detect'

CODE_MTHD_NOT_SPRT = -1
CODE_INV_URL = -2
CODE_SYS_ERR = -3
CODE_SUCCESS = 0