MODEL_VGG_PATH = '/var/www/vgg16/vggface.npy'
MODEL_DNN_PATH = '/var/www/vgg16/model-tf-50'
UID_PATH = '/var/www/vgg16/uid.txt'
CVDATA_PATH = '/var/www/vgg16/cvdata/haarcascade_frontalface_default.xml'