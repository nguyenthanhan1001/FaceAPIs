import VggRecogniser as vggrgn
rgn = vggrgn.VggRecogniser()
print rgn.recognise('4.jpg')