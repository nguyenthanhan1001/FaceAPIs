MODEL_VGG_PATH = '/home/mmhci_hcmus/vggface/vggface.npy'
MODEL_DNN_PATH = '/home/mmhci_hcmus/pretrained/QuocHoi/model-69'
UID_PATH       = '/home/mmhci_hcmus/pretrained/QuocHoi/uid.txt'
CVDATA_PATH    = '/home/mmhci_hcmus/vggface/cvdata/haarcascade_frontalface_default.xml'
