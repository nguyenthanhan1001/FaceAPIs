API_DETECT = 'http://128.199.90.168:8000/detect'
API_RECOGNISE = 'http://128.199.205.131:8000/recognise'